import React from 'react'
import Card from './Card'

const CardView = () => {
  return (
    <>
        <Card />
        <Card />
    </>
  )
}

export default CardView