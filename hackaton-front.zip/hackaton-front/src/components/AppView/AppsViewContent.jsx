import React from 'react'
import AppsView from './AppsView'

const AppsViewContent = () => {
  return (
    <>
        <AppsView />
    </>
  )
}

export default AppsViewContent