import React from 'react'

const AppsView = () => {
  return (
    <>
        
    </>
  )
}

export default AppsView